var secretWord;


function apiCall(){
    //GET Request because it has JUST a URL
    //Asynchronous Function
    let length=5;
    fetch(`https://random-word-api.vercel.app/api?words=1&length=${length}`)
   
    .then(response => {
        console.log(response);
        if (!response.ok) {
        throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        console.log('Data:', data);
        secretWord = data[0].toUpperCase();
        // Handle the data here
    })
    .catch(error => {
        console.error('Error fetching data:', error);
        // Handle errors here
    });
}

window.onload = function(){
    console.log("Page Loaded");
    generateWordle();
   
    apiCall();
}
 
var numGuesses = 0;
 
 
function generateWordle(){
   
    var container = document.getElementById("container");
 
    //outer for loop for rows
    for(let ii = 0; ii < 6; ii++){
        //create inner loop for columns
        var div = document.createElement("div");
        for(let jj = 0; jj < 5; jj++){
            let input = document.createElement("input");
           
            input.type = "text";
            input.style.width = "1.5ch"; //changes the width of the input field to be 1 character
            input.maxLength = 1;
            input.setAttribute("oninput", "myFunction(this)");
           
           
            div.appendChild(input);
            if (ii != 0){
                input.disabled = true;
            }
            //console.log(div);
        }
        container.appendChild(div);
        div.innerHTML += `<br>`;
    }
   //This code adds an "onKeyUp" event to each child div of container. (row)
var childs = container.children;
for (ii = 0; ii< childs.length;ii++){
      childs[ii].onkeyup = goNext;    
}



//Outside the generateWordle code you will paste the following function. 

function goNext(event) {
//https://stackoverflow.com/questions/15595652/focus-next-input-once-reaching-maxlength-value
var target = event.srcElement; //checks the srcEement or the target if srcElement is null
var myLength = target.value.length; //find the length of the text in the input
if (myLength >= 1) { //if we entered a single character
    var next = target; //sets self to current target (Temporary)
    while (next = next.nextElementSibling) { //goes to the next sibling element  that is an "input tag"
        if (next == null) //if it finds a null value(end of children)
            break; //exit loop
        if (next.tagName.toLowerCase() === "input") { //if the value is an input
            next.focus(); //focus on it.
            break;
        }
    }
}
else if (myLength === 0) {
    var previous = target;
    while (previous = previous.previousElementSibling) {
        if (previous == null)
            break;
        if (previous.tagName.toLowerCase() === "input") {
            previous.focus();
            break;
        }
    }
}
}
    var myButt = document.createElement("button");
    myButt.setAttribute("onclick","checkWord()");
    myButt.innerHTML = "Check Word";
    container.appendChild(myButt);
}

function checkWord(){
    let guess = "";
    var container = document.getElementById("container");
    var rows = container.children;

    var currentRow = rows[numGuesses]; // dynamically select the current row

    // Loop through the 5 inputs in the current row
    for (let i = 0; i < currentRow.children.length; i++) {
        let input = currentRow.children[i];
        if (input.tagName.toLowerCase() === "input") {
            guess += input.value;
        }
    }

    // Ensure the guess is exactly 5 characters
    if (guess.length < 5) {
        document.getElementById("message").innerHTML = "<p>Please enter a 5-letter word.</p>";
        return;
    }


var url = "https://api.dictionaryapi.dev/api/v2/entries/en/" + guess;
        var message = document.getElementById("message");
            //GET Request because it has JUST a URL
        //Asynchronous Function
        fetch(url)    
        .then(response => {
            //console.log(response);
            if (!response.ok) {
            throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log('Data:', data);
            message.innerHTML = `<p>Your word: ${guess} is a word</p>`;
            validator(guess);
 
            // Handle the data here
        })
        .catch(error => {
            console.error('Error fetching data:', error);
            message.innerHTML = `<p>Your word: ${guess} is made up</p>`
 
            // Handle errors here
        });



}

function validator(word){
    if (word === secretWord) {
        alert("Congratulations! You've guessed the word!");
    } else {
        alert("That's not a valid word. Please guess again.");
        numGuesses++
    }
    if (numGuesses >= 6) {
        alert("Game Over");
        return;
    }
    alert("Incorrect, try again.");
    var container= document.getElementById("container");
    var rows = container.children;
    var nextRow = rows[numGuesses]; 

    // Enable inputs in the next row
    for (let i = 0; i < nextRow.children.length; i++) {
        let input = nextRow.children[i];
        if (input.tagName.toLowerCase() === "input") {
            input.disabled = false;
        }
    }

    // to focus on the first input of the next row
    for (let i = 0; i < nextRow.children.length; i++) {
        if (nextRow.children[i].tagName.toLowerCase() === "input") {
            nextRow.children[i].focus();
            break;
        }
    }
}

function myFunction(bobby){
    if (!(/[A-Za-z]/.test(bobby.value))){
        bobby.value="";
    }
    else{
        console.log("Oninput working: "+ bobby.value);
        bobby.value = bobby.value.toUpperCase();
    }
 
}
